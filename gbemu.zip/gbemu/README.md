# gbemu — a Game Boy (DMG) emulator in C++

Passes all of Blargg's `cpu_instrs` tests and `instr_timing`.

## Build on macOS

```bash
xcode-select --install          # compiler (skip if already installed)
brew install cmake sdl2

cd gbemu
cmake -S . -B build
cmake --build build -j
```

If CMake can't find SDL2, add `-DCMAKE_PREFIX_PATH=$(brew --prefix)` to the first cmake command.

## Run

```bash
./build/gbemu path/to/game.gb
```

| Key | Game Boy |
|---|---|
| Arrow keys | D-pad |
| X | A |
| Z | B |
| Enter | Start |
| Backspace / Right Shift | Select |
| Space (hold) | Fast-forward |
| Esc | Quit |

Battery saves are written next to the ROM as `game.sav` when you quit.

## Run the test ROMs

Get them from https://github.com/retrio/gb-test-roms, then:

```bash
./build/gbemu gb-test-roms/cpu_instrs/cpu_instrs.gb --headless 4000
```

The test prints its result through the serial port, which headless mode shows in the terminal.

## How the code is organised

| File | What it does |
|---|---|
| `src/cpu.cpp` | SM83 CPU: registers, flags, all 512 opcodes, interrupts, HALT |
| `src/mmu.cpp` | Memory bus: routes every address, joypad, serial, OAM DMA |
| `src/ppu.cpp` | Graphics: scanline timing, background, window, sprites |
| `src/timer.cpp` | DIV/TIMA timer and its interrupt |
| `src/cartridge.cpp` | ROM loading, MBC1/MBC3/MBC5 bank switching, saves |
| `src/gameboy.h` | Wires everything together, runs one frame at a time |
| `src/main.cpp` | SDL window, keyboard input, 59.7 fps frame pacing |

## Not implemented yet (good next steps)

- **Sound (APU)**: the four channels at 0xFF10–0xFF3F. Registers are stored but no audio is produced.
- **MBC2** and the **MBC3 real-time clock** (Pokémon Gold/Silver's clock won't tick).
- **Game Boy Color** mode.
- Cycle-exact memory timing (needed for `mem_timing` tests and a few picky games).

## ROMs

Use free test ROMs, homebrew games, or cartridges you've dumped yourself.
