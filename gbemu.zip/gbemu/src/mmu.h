#pragma once
#include <array>
#include <cstdint>
#include <string>

#include "cartridge.h"
#include "ppu.h"
#include "timer.h"

// The memory bus. Every CPU read/write goes through here and is routed
// to the right component based on the address.
class MMU {
public:
    enum Button { Right, Left, Up, Down, A, B, Select, Start };

    MMU(Cartridge& cart, PPU& ppu, Timer& timer, uint8_t& interruptFlags)
        : IF(interruptFlags), cart(cart), ppu(ppu), timer(timer) {
        wram.fill(0);
        hram.fill(0);
        io.fill(0xFF);
    }

    uint8_t read(uint16_t addr);
    void write(uint16_t addr, uint8_t value);

    void setButton(Button b, bool pressed);

    uint8_t& IF;        // interrupt request flags (0xFF0F)
    uint8_t IE = 0;     // interrupt enable (0xFFFF)
    std::string serialOutput;   // test ROMs print their results through the serial port

private:
    Cartridge& cart;
    PPU& ppu;
    Timer& timer;

    std::array<uint8_t, 0x2000> wram;
    std::array<uint8_t, 0x7F> hram;
    std::array<uint8_t, 0x80> io;   // generic storage for unhandled I/O (e.g. sound)

    uint8_t joypadSelect = 0x30;
    uint8_t buttons = 0;            // bit set = pressed, ordered like Button
    uint8_t serialData = 0, serialControl = 0;

    uint8_t readIO(uint16_t addr);
    void writeIO(uint16_t addr, uint8_t value);
    uint8_t readJoypad() const;
};
