#include "timer.h"

// TIMA increments when the chosen bit of the internal counter falls 1 -> 0.
int Timer::selectedBit() const {
    switch (tac & 0x03) {
        case 0:  return 9;  //   4096 Hz
        case 1:  return 3;  // 262144 Hz
        case 2:  return 5;  //  65536 Hz
        default: return 7;  //  16384 Hz
    }
}

void Timer::incrementTima() {
    if (++tima == 0) {      // overflow: reload from TMA and request interrupt
        tima = tma;
        IF |= 0x04;
    }
}

void Timer::tick(int cycles) {
    for (int i = 0; i < cycles; i++) {
        uint16_t old = div++;
        if (tac & 0x04) {
            int bit = selectedBit();
            if (((old >> bit) & 1) && !((div >> bit) & 1)) incrementTima();
        }
    }
}

uint8_t Timer::read(uint16_t addr) const {
    switch (addr) {
        case 0xFF04: return div >> 8;
        case 0xFF05: return tima;
        case 0xFF06: return tma;
        default:     return tac | 0xF8;
    }
}

void Timer::write(uint16_t addr, uint8_t value) {
    switch (addr) {
        case 0xFF04:
            // Resetting DIV can itself cause a falling edge
            if ((tac & 0x04) && ((div >> selectedBit()) & 1)) incrementTima();
            div = 0;
            break;
        case 0xFF05: tima = value; break;
        case 0xFF06: tma = value; break;
        default:     tac = value & 0x07; break;
    }
}
