#include "cpu.h"

#include <cstdio>

#include "mmu.h"

// ---------------------------------------------------------------- helpers

uint8_t CPU::fetch8() { return mmu.read(pc++); }

uint16_t CPU::fetch16() {
    uint8_t lo = fetch8();
    uint8_t hi = fetch8();
    return static_cast<uint16_t>((hi << 8) | lo);
}

void CPU::push(uint16_t v) {
    mmu.write(--sp, v >> 8);
    mmu.write(--sp, v & 0xFF);
}

uint16_t CPU::pop() {
    uint8_t lo = mmu.read(sp++);
    uint8_t hi = mmu.read(sp++);
    return static_cast<uint16_t>((hi << 8) | lo);
}

uint8_t CPU::getR(int i) {
    switch (i) {
        case 0: return b;  case 1: return c;
        case 2: return d;  case 3: return e;
        case 4: return h;  case 5: return l;
        case 6: return mmu.read(hl());
        default: return a;
    }
}

void CPU::setR(int i, uint8_t v) {
    switch (i) {
        case 0: b = v; break;  case 1: c = v; break;
        case 2: d = v; break;  case 3: e = v; break;
        case 4: h = v; break;  case 5: l = v; break;
        case 6: mmu.write(hl(), v); break;
        default: a = v; break;
    }
}

uint16_t CPU::getRR(int i) const {
    switch (i) {
        case 0: return bc();
        case 1: return de();
        case 2: return hl();
        default: return sp;
    }
}

void CPU::setRR(int i, uint16_t v) {
    switch (i) {
        case 0: setBC(v); break;
        case 1: setDE(v); break;
        case 2: setHL(v); break;
        default: sp = v; break;
    }
}

bool CPU::condition(int cc) const {
    switch (cc) {
        case 0: return !flag(FZ);
        case 1: return flag(FZ);
        case 2: return !flag(FC);
        default: return flag(FC);
    }
}

// ---------------------------------------------------------------- arithmetic

void CPU::alu(int op, uint8_t v) {
    switch (op) {
        case 0:   // ADD
        case 1: { // ADC
            int carry = (op == 1 && flag(FC)) ? 1 : 0;
            int r = a + v + carry;
            setFlag(FH, (a & 0xF) + (v & 0xF) + carry > 0xF);
            setFlag(FC, r > 0xFF);
            setFlag(FN, false);
            a = static_cast<uint8_t>(r);
            setFlag(FZ, a == 0);
            break;
        }
        case 2:   // SUB
        case 3:   // SBC
        case 7: { // CP (subtract but throw the result away)
            int carry = (op == 3 && flag(FC)) ? 1 : 0;
            int r = a - v - carry;
            setFlag(FH, (a & 0xF) - (v & 0xF) - carry < 0);
            setFlag(FC, r < 0);
            setFlag(FN, true);
            setFlag(FZ, static_cast<uint8_t>(r) == 0);
            if (op != 7) a = static_cast<uint8_t>(r);
            break;
        }
        case 4: a &= v; f = (a ? 0 : FZ) | FH; break;   // AND
        case 5: a ^= v; f = a ? 0 : FZ; break;          // XOR
        case 6: a |= v; f = a ? 0 : FZ; break;          // OR
    }
}

uint8_t CPU::inc(uint8_t v) {
    uint8_t r = v + 1;
    setFlag(FZ, r == 0);
    setFlag(FN, false);
    setFlag(FH, (v & 0xF) == 0xF);
    return r;
}

uint8_t CPU::dec(uint8_t v) {
    uint8_t r = v - 1;
    setFlag(FZ, r == 0);
    setFlag(FN, true);
    setFlag(FH, (v & 0xF) == 0);
    return r;
}

void CPU::addHL(uint16_t v) {
    int r = hl() + v;
    setFlag(FN, false);
    setFlag(FH, (hl() & 0xFFF) + (v & 0xFFF) > 0xFFF);
    setFlag(FC, r > 0xFFFF);
    setHL(static_cast<uint16_t>(r));
}

// Used by ADD SP,e and LD HL,SP+e: flags come from the low byte
uint16_t CPU::addSPSigned() {
    uint8_t raw = fetch8();
    int8_t offset = static_cast<int8_t>(raw);
    f = 0;
    setFlag(FH, (sp & 0xF) + (raw & 0xF) > 0xF);
    setFlag(FC, (sp & 0xFF) + raw > 0xFF);
    return static_cast<uint16_t>(sp + offset);
}

// Decimal adjust: fixes A after adding/subtracting two BCD numbers
void CPU::daa() {
    uint8_t adjust = 0;
    bool carry = flag(FC);
    if (!flag(FN)) {
        if (flag(FC) || a > 0x99) { adjust |= 0x60; carry = true; }
        if (flag(FH) || (a & 0x0F) > 0x09) adjust |= 0x06;
        a += adjust;
    } else {
        if (flag(FC)) adjust |= 0x60;
        if (flag(FH)) adjust |= 0x06;
        a -= adjust;
    }
    setFlag(FZ, a == 0);
    setFlag(FH, false);
    setFlag(FC, carry);
}

// ---------------------------------------------------------------- main loop

int CPU::step() {
    uint8_t pending = mmu.IE & mmu.IF & 0x1F;

    if (halted) {
        if (!pending) return 4;     // sleep until an interrupt is requested
        halted = false;
    }

    // Service an interrupt: VBlank(0x40) STAT(0x48) Timer(0x50) Serial(0x58) Joypad(0x60)
    if (ime && pending) {
        int bit = 0;
        while (!(pending & (1 << bit))) bit++;
        mmu.IF &= ~(1 << bit);
        ime = false;
        push(pc);
        pc = 0x40 + bit * 8;
        return 20;
    }

    bool enableAfter = imeScheduled;
    int cycles = execute(fetch8());
    if (enableAfter && imeScheduled) { ime = true; imeScheduled = false; }
    return cycles;
}

// Returns T-cycles. Many opcodes share a bit pattern, so they're decoded in groups.
int CPU::execute(uint8_t op) {
    // 0x40-0x7F: LD r, r'   (0x76 is HALT)
    if (op >= 0x40 && op <= 0x7F) {
        if (op == 0x76) { halted = true; return 4; }
        int dst = (op >> 3) & 7, src = op & 7;
        setR(dst, getR(src));
        return (dst == 6 || src == 6) ? 8 : 4;
    }
    // 0x80-0xBF: ALU A, r
    if (op >= 0x80 && op <= 0xBF) {
        int src = op & 7;
        alu((op >> 3) & 7, getR(src));
        return src == 6 ? 8 : 4;
    }

    switch (op) {
        case 0x00: return 4;                                   // NOP
        case 0x10: fetch8(); return 4;                         // STOP

        // LD rr, nn
        case 0x01: case 0x11: case 0x21: case 0x31:
            setRR(op >> 4, fetch16()); return 12;

        // LD (rr), A  /  LD A, (rr)  with HL+/HL- variants
        case 0x02: mmu.write(bc(), a); return 8;
        case 0x12: mmu.write(de(), a); return 8;
        case 0x22: mmu.write(hl(), a); setHL(hl() + 1); return 8;
        case 0x32: mmu.write(hl(), a); setHL(hl() - 1); return 8;
        case 0x0A: a = mmu.read(bc()); return 8;
        case 0x1A: a = mmu.read(de()); return 8;
        case 0x2A: a = mmu.read(hl()); setHL(hl() + 1); return 8;
        case 0x3A: a = mmu.read(hl()); setHL(hl() - 1); return 8;

        // INC rr / DEC rr (no flags)
        case 0x03: case 0x13: case 0x23: case 0x33:
            setRR(op >> 4, getRR(op >> 4) + 1); return 8;
        case 0x0B: case 0x1B: case 0x2B: case 0x3B:
            setRR(op >> 4, getRR(op >> 4) - 1); return 8;

        // INC r / DEC r
        case 0x04: case 0x0C: case 0x14: case 0x1C: case 0x24: case 0x2C: case 0x34: case 0x3C: {
            int r = (op >> 3) & 7;
            setR(r, inc(getR(r)));
            return r == 6 ? 12 : 4;
        }
        case 0x05: case 0x0D: case 0x15: case 0x1D: case 0x25: case 0x2D: case 0x35: case 0x3D: {
            int r = (op >> 3) & 7;
            setR(r, dec(getR(r)));
            return r == 6 ? 12 : 4;
        }

        // LD r, n
        case 0x06: case 0x0E: case 0x16: case 0x1E: case 0x26: case 0x2E: case 0x36: case 0x3E: {
            int r = (op >> 3) & 7;
            setR(r, fetch8());
            return r == 6 ? 12 : 8;
        }

        // ADD HL, rr
        case 0x09: case 0x19: case 0x29: case 0x39:
            addHL(getRR(op >> 4)); return 8;

        // Rotates on A (Z flag is always cleared)
        case 0x07: { uint8_t c7 = a >> 7; a = (a << 1) | c7; f = c7 ? FC : 0; return 4; }           // RLCA
        case 0x0F: { uint8_t c0 = a & 1; a = (a >> 1) | (c0 << 7); f = c0 ? FC : 0; return 4; }     // RRCA
        case 0x17: { uint8_t c7 = a >> 7; a = (a << 1) | (flag(FC) ? 1 : 0); f = c7 ? FC : 0; return 4; }    // RLA
        case 0x1F: { uint8_t c0 = a & 1; a = (a >> 1) | (flag(FC) ? 0x80 : 0); f = c0 ? FC : 0; return 4; } // RRA

        case 0x08: {                                           // LD (nn), SP
            uint16_t addr = fetch16();
            mmu.write(addr, sp & 0xFF);
            mmu.write(addr + 1, sp >> 8);
            return 20;
        }

        // Relative jumps
        case 0x18: { int8_t off = static_cast<int8_t>(fetch8()); pc += off; return 12; }
        case 0x20: case 0x28: case 0x30: case 0x38: {
            int8_t off = static_cast<int8_t>(fetch8());
            if (condition((op >> 3) & 3)) { pc += off; return 12; }
            return 8;
        }

        case 0x27: daa(); return 4;                                                   // DAA
        case 0x2F: a = ~a; setFlag(FN, true); setFlag(FH, true); return 4;            // CPL
        case 0x37: setFlag(FN, false); setFlag(FH, false); setFlag(FC, true); return 4;       // SCF
        case 0x3F: setFlag(FN, false); setFlag(FH, false); setFlag(FC, !flag(FC)); return 4;  // CCF

        // Returns
        case 0xC0: case 0xC8: case 0xD0: case 0xD8:
            if (condition((op >> 3) & 3)) { pc = pop(); return 20; }
            return 8;
        case 0xC9: pc = pop(); return 16;                         // RET
        case 0xD9: pc = pop(); ime = true; return 16;             // RETI

        // POP / PUSH
        case 0xC1: setBC(pop()); return 12;
        case 0xD1: setDE(pop()); return 12;
        case 0xE1: setHL(pop()); return 12;
        case 0xF1: { uint16_t v = pop(); a = v >> 8; f = v & 0xF0; return 12; }
        case 0xC5: push(bc()); return 16;
        case 0xD5: push(de()); return 16;
        case 0xE5: push(hl()); return 16;
        case 0xF5: push(static_cast<uint16_t>((a << 8) | f)); return 16;

        // Absolute jumps
        case 0xC3: pc = fetch16(); return 16;
        case 0xC2: case 0xCA: case 0xD2: case 0xDA: {
            uint16_t addr = fetch16();
            if (condition((op >> 3) & 3)) { pc = addr; return 16; }
            return 12;
        }
        case 0xE9: pc = hl(); return 4;                           // JP HL

        // Calls
        case 0xCD: { uint16_t addr = fetch16(); push(pc); pc = addr; return 24; }
        case 0xC4: case 0xCC: case 0xD4: case 0xDC: {
            uint16_t addr = fetch16();
            if (condition((op >> 3) & 3)) { push(pc); pc = addr; return 24; }
            return 12;
        }

        // RST n
        case 0xC7: case 0xCF: case 0xD7: case 0xDF: case 0xE7: case 0xEF: case 0xF7: case 0xFF:
            push(pc); pc = op & 0x38; return 16;

        // ALU A, n
        case 0xC6: case 0xCE: case 0xD6: case 0xDE: case 0xE6: case 0xEE: case 0xF6: case 0xFE:
            alu((op >> 3) & 7, fetch8()); return 8;

        // High-memory loads (0xFF00 + offset)
        case 0xE0: mmu.write(0xFF00 + fetch8(), a); return 12;
        case 0xF0: a = mmu.read(0xFF00 + fetch8()); return 12;
        case 0xE2: mmu.write(0xFF00 + c, a); return 8;
        case 0xF2: a = mmu.read(0xFF00 + c); return 8;
        case 0xEA: mmu.write(fetch16(), a); return 16;
        case 0xFA: a = mmu.read(fetch16()); return 16;

        // Stack pointer arithmetic
        case 0xE8: sp = addSPSigned(); return 16;
        case 0xF8: setHL(addSPSigned()); return 12;
        case 0xF9: sp = hl(); return 8;

        case 0xF3: ime = false; imeScheduled = false; return 4;   // DI
        case 0xFB: imeScheduled = true; return 4;                 // EI

        case 0xCB: return executeCB();

        default:
            std::fprintf(stderr, "Illegal opcode 0x%02X at 0x%04X\n", op, pc - 1);
            return 4;
    }
}

// CB-prefixed opcodes: rotates, shifts, SWAP, and single-bit operations
int CPU::executeCB() {
    uint8_t op = fetch8();
    int r = op & 7;
    int group = op >> 6;
    int y = (op >> 3) & 7;
    uint8_t v = getR(r);

    if (group == 1) {                                   // BIT y, r
        setFlag(FZ, !(v & (1 << y)));
        setFlag(FN, false);
        setFlag(FH, true);
        return r == 6 ? 12 : 8;
    }
    if (group == 2) { setR(r, v & ~(1 << y)); return r == 6 ? 16 : 8; }   // RES
    if (group == 3) { setR(r, v | (1 << y));  return r == 6 ? 16 : 8; }   // SET

    uint8_t result;
    bool carry;
    switch (y) {
        case 0: carry = v >> 7; result = (v << 1) | (v >> 7); break;                  // RLC
        case 1: carry = v & 1;  result = (v >> 1) | (v << 7); break;                  // RRC
        case 2: carry = v >> 7; result = (v << 1) | (flag(FC) ? 1 : 0); break;        // RL
        case 3: carry = v & 1;  result = (v >> 1) | (flag(FC) ? 0x80 : 0); break;     // RR
        case 4: carry = v >> 7; result = v << 1; break;                               // SLA
        case 5: carry = v & 1;  result = (v >> 1) | (v & 0x80); break;                // SRA
        case 6: carry = false;  result = (v >> 4) | (v << 4); break;                  // SWAP
        default: carry = v & 1; result = v >> 1; break;                               // SRL
    }
    setR(r, result);
    f = (result ? 0 : FZ) | (carry ? FC : 0);
    return r == 6 ? 16 : 8;
}
