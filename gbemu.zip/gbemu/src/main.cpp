#include <SDL.h>

#include <cstdio>
#include <cstdlib>
#include <string>

#include "gameboy.h"

static constexpr int SCALE = 4;   // window is 640x576

// Keyboard -> Game Boy button mapping
static bool mapKey(SDL_Keycode key, MMU::Button& out) {
    switch (key) {
        case SDLK_RIGHT:     out = MMU::Right;  return true;
        case SDLK_LEFT:      out = MMU::Left;   return true;
        case SDLK_UP:        out = MMU::Up;     return true;
        case SDLK_DOWN:      out = MMU::Down;   return true;
        case SDLK_x:         out = MMU::A;      return true;
        case SDLK_z:         out = MMU::B;      return true;
        case SDLK_RETURN:    out = MMU::Start;  return true;
        case SDLK_BACKSPACE:
        case SDLK_RSHIFT:    out = MMU::Select; return true;
        default:             return false;
    }
}

int main(int argc, char* argv[]) {
    if (argc < 2) {
        std::printf("Usage: %s <rom.gb> [--headless <frames>]\n", argv[0]);
        return 1;
    }

    Cartridge cart;
    if (!cart.load(argv[1])) return 1;
    GameBoy gb(cart);

    // Headless mode: run N frames with no window and print serial output.
    // Handy for test ROMs like Blargg's cpu_instrs.
    if (argc >= 4 && std::string(argv[2]) == "--headless") {
        int frames = std::atoi(argv[3]);
        for (int i = 0; i < frames; i++) gb.runFrame();
        std::printf("%s\n", gb.mmu.serialOutput.c_str());
        return 0;
    }

    if (SDL_Init(SDL_INIT_VIDEO) != 0) {
        std::fprintf(stderr, "SDL_Init failed: %s\n", SDL_GetError());
        return 1;
    }

    std::string title = "GB Emu - " + cart.title();
    SDL_Window* window = SDL_CreateWindow(title.c_str(), SDL_WINDOWPOS_CENTERED, SDL_WINDOWPOS_CENTERED,
                                          PPU::WIDTH * SCALE, PPU::HEIGHT * SCALE,
                                          SDL_WINDOW_ALLOW_HIGHDPI | SDL_WINDOW_RESIZABLE);
    SDL_Renderer* renderer = SDL_CreateRenderer(window, -1, SDL_RENDERER_ACCELERATED);
    SDL_RenderSetLogicalSize(renderer, PPU::WIDTH, PPU::HEIGHT);   // keeps aspect ratio when resized
    SDL_SetHint(SDL_HINT_RENDER_SCALE_QUALITY, "0");                 // crisp pixels
    SDL_Texture* texture = SDL_CreateTexture(renderer, SDL_PIXELFORMAT_ARGB8888,
                                             SDL_TEXTUREACCESS_STREAMING, PPU::WIDTH, PPU::HEIGHT);

    // We time frames ourselves instead of relying on vsync, because
    // ProMotion Macs refresh at 120 Hz and the game would run 2x speed.
    const double frameSeconds = static_cast<double>(GameBoy::CYCLES_PER_FRAME) / 4194304.0;
    const Uint64 freq = SDL_GetPerformanceFrequency();
    Uint64 nextFrame = SDL_GetPerformanceCounter();

    bool running = true;
    bool fastForward = false;

    while (running) {
        SDL_Event event;
        while (SDL_PollEvent(&event)) {
            if (event.type == SDL_QUIT) running = false;
            if (event.type == SDL_KEYDOWN || event.type == SDL_KEYUP) {
                bool down = event.type == SDL_KEYDOWN;
                SDL_Keycode key = event.key.keysym.sym;
                if (key == SDLK_ESCAPE && down) running = false;
                if (key == SDLK_SPACE) fastForward = down;     // hold Space to fast-forward
                MMU::Button button;
                if (mapKey(key, button)) gb.mmu.setButton(button, down);
            }
        }

        gb.runFrame();

        SDL_UpdateTexture(texture, nullptr, gb.ppu.pixels(), PPU::WIDTH * sizeof(uint32_t));
        SDL_RenderClear(renderer);
        SDL_RenderCopy(renderer, texture, nullptr, nullptr);
        SDL_RenderPresent(renderer);

        // Wait until it's time for the next frame
        nextFrame += static_cast<Uint64>(frameSeconds * freq);
        Uint64 now = SDL_GetPerformanceCounter();
        if (fastForward || now > nextFrame) {
            nextFrame = now;                   // don't try to "catch up" after a stall
        } else {
            double waitMs = static_cast<double>(nextFrame - now) * 1000.0 / freq;
            if (waitMs > 1.0) SDL_Delay(static_cast<Uint32>(waitMs - 1.0));
            while (SDL_GetPerformanceCounter() < nextFrame) {}   // fine-grained spin
        }
    }

    cart.saveRam();   // write battery save (.sav) on exit

    SDL_DestroyTexture(texture);
    SDL_DestroyRenderer(renderer);
    SDL_DestroyWindow(window);
    SDL_Quit();
    return 0;
}
