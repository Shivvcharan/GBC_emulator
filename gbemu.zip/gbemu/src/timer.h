#pragma once
#include <cstdint>

// DIV / TIMA / TMA / TAC timer registers (0xFF04-0xFF07).
class Timer {
public:
    explicit Timer(uint8_t& interruptFlags) : IF(interruptFlags) {}

    void tick(int cycles);                 // advance by T-cycles
    uint8_t read(uint16_t addr) const;
    void write(uint16_t addr, uint8_t value);

private:
    uint8_t& IF;
    uint16_t div = 0xABCC;  // internal 16-bit counter; DIV register is the top byte
    uint8_t tima = 0, tma = 0, tac = 0xF8;

    int selectedBit() const;
    void incrementTima();
};
