#pragma once
#include <cstdint>
#include <string>
#include <vector>

// Holds the game ROM, the cartridge RAM and the "memory bank controller"
// (MBC) logic that lets games bigger than 32 KB swap banks in and out.
class Cartridge {
public:
    bool load(const std::string& path);
    void saveRam() const;           // writes battery-backed RAM to a .sav file

    uint8_t read(uint16_t addr) const;   // 0x0000-0x7FFF and 0xA000-0xBFFF
    void write(uint16_t addr, uint8_t value);

    std::string title() const;

private:
    enum class MBC { None, MBC1, MBC3, MBC5 };

    std::vector<uint8_t> rom;
    std::vector<uint8_t> ram;
    std::string savePath;

    MBC  mbc = MBC::None;
    bool hasBattery = false;
    bool ramEnabled = false;

    int romBank = 1;     // bank mapped at 0x4000-0x7FFF
    int ramBank = 0;     // bank mapped at 0xA000-0xBFFF

    // MBC1 specifics
    int mbc1Low = 1;     // 5-bit ROM bank register
    int mbc1High = 0;    // 2-bit upper/RAM bank register
    int mbc1Mode = 0;    // banking mode select
};
