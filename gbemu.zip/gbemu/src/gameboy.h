#pragma once
#include "cartridge.h"
#include "cpu.h"
#include "mmu.h"
#include "ppu.h"
#include "timer.h"

// Wires all the components together. Member order matters: things are
// constructed top to bottom, and later members hold references to earlier ones.
class GameBoy {
public:
    static constexpr int CYCLES_PER_FRAME = 70224;   // ~59.7 frames per second

    explicit GameBoy(Cartridge& cart)
        : ppu(interruptFlags), timer(interruptFlags),
          mmu(cart, ppu, timer, interruptFlags), cpu(mmu) {}

    // Runs the CPU until the PPU finishes a frame (or one frame's worth of
    // time passes while the screen is off).
    void runFrame() {
        ppu.frameReady = false;
        int cycles = 0;
        while (!ppu.frameReady) {
            int c = cpu.step();
            timer.tick(c);
            ppu.tick(c);
            cycles += c;
            if (!ppu.lcdOn() && cycles >= CYCLES_PER_FRAME) break;
        }
    }

    uint8_t interruptFlags = 0xE1;
    PPU ppu;
    Timer timer;
    MMU mmu;
    CPU cpu;
};
