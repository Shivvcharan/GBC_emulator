#include "mmu.h"

// Memory map:
//   0000-7FFF  cartridge ROM       A000-BFFF  cartridge RAM
//   8000-9FFF  video RAM           C000-DFFF  work RAM (E000-FDFF mirrors it)
//   FE00-FE9F  sprite table (OAM)  FF00-FF7F  I/O registers
//   FF80-FFFE  high RAM            FFFF       interrupt enable
uint8_t MMU::read(uint16_t addr) {
    if (addr < 0x8000) return cart.read(addr);
    if (addr < 0xA000) return ppu.readVRAM(addr);
    if (addr < 0xC000) return cart.read(addr);
    if (addr < 0xE000) return wram[addr - 0xC000];
    if (addr < 0xFE00) return wram[addr - 0xE000];
    if (addr < 0xFEA0) return ppu.readOAM(addr);
    if (addr < 0xFF00) return 0xFF;               // unusable region
    if (addr < 0xFF80) return readIO(addr);
    if (addr < 0xFFFF) return hram[addr - 0xFF80];
    return IE;
}

void MMU::write(uint16_t addr, uint8_t value) {
    if (addr < 0x8000)      cart.write(addr, value);
    else if (addr < 0xA000) ppu.writeVRAM(addr, value);
    else if (addr < 0xC000) cart.write(addr, value);
    else if (addr < 0xE000) wram[addr - 0xC000] = value;
    else if (addr < 0xFE00) wram[addr - 0xE000] = value;
    else if (addr < 0xFEA0) ppu.writeOAM(addr, value);
    else if (addr < 0xFF00) {}
    else if (addr < 0xFF80) writeIO(addr, value);
    else if (addr < 0xFFFF) hram[addr - 0xFF80] = value;
    else                    IE = value;
}

uint8_t MMU::readIO(uint16_t addr) {
    if (addr == 0xFF00) return readJoypad();
    if (addr == 0xFF01) return serialData;
    if (addr == 0xFF02) return serialControl | 0x7E;
    if (addr >= 0xFF04 && addr <= 0xFF07) return timer.read(addr);
    if (addr == 0xFF0F) return IF | 0xE0;
    if (addr >= 0xFF40 && addr <= 0xFF4B && addr != 0xFF46) return ppu.readReg(addr);
    return io[addr - 0xFF00];
}

void MMU::writeIO(uint16_t addr, uint8_t value) {
    if (addr == 0xFF00) { joypadSelect = value & 0x30; return; }
    if (addr == 0xFF01) { serialData = value; return; }
    if (addr == 0xFF02) {
        // No link cable: "transfer" instantly and keep the byte (great for test ROMs)
        if (value & 0x80) {
            serialOutput += static_cast<char>(serialData);
            serialData = 0xFF;
            IF |= 0x08;
            value &= 0x7F;
        }
        serialControl = value;
        return;
    }
    if (addr >= 0xFF04 && addr <= 0xFF07) { timer.write(addr, value); return; }
    if (addr == 0xFF0F) { IF = value & 0x1F; return; }
    if (addr == 0xFF46) {
        // OAM DMA: copy 160 bytes from value*0x100 into sprite memory
        uint16_t src = value << 8;
        for (int i = 0; i < 0xA0; i++) ppu.writeOAM(0xFE00 + i, read(src + i));
        io[addr - 0xFF00] = value;
        return;
    }
    if (addr >= 0xFF40 && addr <= 0xFF4B) { ppu.writeReg(addr, value); return; }
    io[addr - 0xFF00] = value;   // sound and other registers: just store
}

uint8_t MMU::readJoypad() const {
    uint8_t result = 0xC0 | joypadSelect | 0x0F;   // 1 = not pressed
    if (!(joypadSelect & 0x10)) result &= ~(buttons & 0x0F);         // d-pad selected
    if (!(joypadSelect & 0x20)) result &= ~((buttons >> 4) & 0x0F);  // action buttons selected
    return result;
}

void MMU::setButton(Button b, bool pressed) {
    uint8_t mask = 1 << b;
    if (pressed) {
        if (!(buttons & mask)) IF |= 0x10;   // joypad interrupt on press
        buttons |= mask;
    } else {
        buttons &= ~mask;
    }
}
