#include "ppu.h"

#include <algorithm>
#include <vector>

constexpr uint32_t PPU::palette[4];

// Each scanline is 456 cycles: OAM scan (80) -> drawing (172) -> HBlank (204).
// Lines 144-153 are VBlank. A full frame is 154 * 456 = 70224 cycles.
void PPU::tick(int cycles) {
    if (!lcdOn()) return;
    dots += cycles;

    while (true) {
        switch (mode) {
            case 2:
                if (dots < 80) return;
                dots -= 80;
                setMode(3);
                break;
            case 3:
                if (dots < 172) return;
                dots -= 172;
                renderScanline();
                setMode(0);
                break;
            case 0:
                if (dots < 204) return;
                dots -= 204;
                ly++;
                if (ly == 144) {
                    setMode(1);
                    IF |= 0x01;          // VBlank interrupt
                    frameReady = true;
                } else {
                    setMode(2);
                }
                compareLY();
                break;
            case 1:
                if (dots < 456) return;
                dots -= 456;
                ly++;
                if (ly > 153) {
                    ly = 0;
                    windowLine = 0;
                    setMode(2);
                }
                compareLY();
                break;
        }
    }
}

void PPU::setMode(int m) {
    mode = m;
    // STAT interrupt sources: bit 3 HBlank, bit 4 VBlank, bit 5 OAM scan
    if ((m == 0 && (stat & 0x08)) || (m == 1 && (stat & 0x10)) || (m == 2 && (stat & 0x20)))
        IF |= 0x02;
}

void PPU::compareLY() {
    if (ly == lyc && (stat & 0x40)) IF |= 0x02;
}

uint8_t PPU::tilePixel(uint16_t tileAddr, int x, int y) const {
    uint8_t lo = vram[tileAddr + y * 2];
    uint8_t hi = vram[tileAddr + y * 2 + 1];
    int bit = 7 - x;
    return static_cast<uint8_t>((((hi >> bit) & 1) << 1) | ((lo >> bit) & 1));
}

void PPU::renderScanline() {
    uint32_t* line = &framebuffer[ly * WIDTH];
    uint8_t bgIndex[WIDTH] = {0};   // remembered for sprite priority

    // LCDC bit 4 picks the tile data area: 0x8000 (unsigned IDs) or 0x8800 (signed IDs)
    auto tileAddress = [this](uint8_t id) -> uint16_t {
        if (lcdc & 0x10) return id * 16;
        return static_cast<uint16_t>(0x1000 + static_cast<int8_t>(id) * 16);
    };

    // --- Background ---
    if (lcdc & 0x01) {
        uint16_t map = (lcdc & 0x08) ? 0x1C00 : 0x1800;
        uint8_t y = scy + ly;
        for (int x = 0; x < WIDTH; x++) {
            uint8_t px = scx + x;
            uint8_t id = vram[map + (y / 8) * 32 + px / 8];
            uint8_t ci = tilePixel(tileAddress(id), px % 8, y % 8);
            bgIndex[x] = ci;
            line[x] = shade(bgp, ci);
        }

        // --- Window (drawn over the background) ---
        if ((lcdc & 0x20) && wy <= ly && wx <= 166) {
            uint16_t wmap = (lcdc & 0x40) ? 0x1C00 : 0x1800;
            int startX = wx - 7;
            bool drew = false;
            for (int x = std::max(0, startX); x < WIDTH; x++) {
                int wxPos = x - startX;
                uint8_t id = vram[wmap + (windowLine / 8) * 32 + wxPos / 8];
                uint8_t ci = tilePixel(tileAddress(id), wxPos % 8, windowLine % 8);
                bgIndex[x] = ci;
                line[x] = shade(bgp, ci);
                drew = true;
            }
            if (drew) windowLine++;
        }
    } else {
        std::fill(line, line + WIDTH, palette[0]);
    }

    // --- Sprites ---
    if (lcdc & 0x02) {
        int height = (lcdc & 0x04) ? 16 : 8;
        struct Sprite { int x, y, tile, flags, index; };
        std::vector<Sprite> sprites;

        for (int i = 0; i < 40 && sprites.size() < 10; i++) {  // hardware limit: 10 per line
            int sy = oam[i * 4] - 16;
            if (ly >= sy && ly < sy + height)
                sprites.push_back({oam[i * 4 + 1] - 8, sy, oam[i * 4 + 2], oam[i * 4 + 3], i});
        }
        // Lower X wins; ties go to the earlier OAM entry. Draw lowest priority first.
        std::sort(sprites.begin(), sprites.end(), [](const Sprite& a, const Sprite& b) {
            return a.x != b.x ? a.x > b.x : a.index > b.index;
        });

        for (const Sprite& s : sprites) {
            int row = ly - s.y;
            if (s.flags & 0x40) row = height - 1 - row;          // Y flip
            int tile = (height == 16) ? (s.tile & 0xFE) : s.tile;
            uint8_t pal = (s.flags & 0x10) ? obp1 : obp0;

            for (int px = 0; px < 8; px++) {
                int sx = s.x + px;
                if (sx < 0 || sx >= WIDTH) continue;
                int col = (s.flags & 0x20) ? 7 - px : px;          // X flip
                uint8_t ci = tilePixel(static_cast<uint16_t>(tile * 16), col, row);
                if (ci == 0) continue;                             // colour 0 is transparent
                if ((s.flags & 0x80) && bgIndex[sx] != 0) continue; // behind background
                line[sx] = shade(pal, ci);
            }
        }
    }
}

uint8_t PPU::readReg(uint16_t addr) const {
    switch (addr) {
        case 0xFF40: return lcdc;
        case 0xFF41: return 0x80 | (stat & 0x78) | (ly == lyc ? 0x04 : 0) | (lcdOn() ? mode : 0);
        case 0xFF42: return scy;
        case 0xFF43: return scx;
        case 0xFF44: return ly;
        case 0xFF45: return lyc;
        case 0xFF47: return bgp;
        case 0xFF48: return obp0;
        case 0xFF49: return obp1;
        case 0xFF4A: return wy;
        case 0xFF4B: return wx;
        default:     return 0xFF;
    }
}

void PPU::writeReg(uint16_t addr, uint8_t value) {
    switch (addr) {
        case 0xFF40: {
            bool wasOn = lcdOn();
            lcdc = value;
            if (wasOn && !lcdOn()) {             // turning the LCD off resets the PPU
                ly = 0; dots = 0; mode = 0; windowLine = 0;
                framebuffer.fill(palette[0]);
            } else if (!wasOn && lcdOn()) {
                ly = 0; dots = 0; mode = 2; windowLine = 0;
                compareLY();
            }
            break;
        }
        case 0xFF41: stat = value & 0x78; break;
        case 0xFF42: scy = value; break;
        case 0xFF43: scx = value; break;
        case 0xFF45: lyc = value; compareLY(); break;
        case 0xFF47: bgp = value; break;
        case 0xFF48: obp0 = value; break;
        case 0xFF49: obp1 = value; break;
        case 0xFF4A: wy = value; break;
        case 0xFF4B: wx = value; break;
        default: break;                          // LY (0xFF44) is read-only
    }
}
