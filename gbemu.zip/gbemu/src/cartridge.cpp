#include "cartridge.h"

#include <cstdio>
#include <fstream>
#include <iterator>

bool Cartridge::load(const std::string& path) {
    std::ifstream file(path, std::ios::binary);
    if (!file) {
        std::fprintf(stderr, "Could not open ROM: %s\n", path.c_str());
        return false;
    }
    rom.assign(std::istreambuf_iterator<char>(file), {});
    if (rom.size() < 0x8000) rom.resize(0x8000, 0xFF);

    // Cartridge header: 0x0147 = cartridge type, 0x0149 = RAM size
    uint8_t type = rom[0x0147];
    switch (type) {
        case 0x00:                       mbc = MBC::None; break;
        case 0x08:                       mbc = MBC::None; break;
        case 0x09:                       mbc = MBC::None; hasBattery = true; break;
        case 0x01: case 0x02:            mbc = MBC::MBC1; break;
        case 0x03:                       mbc = MBC::MBC1; hasBattery = true; break;
        case 0x11: case 0x12:            mbc = MBC::MBC3; break;
        case 0x0F: case 0x10: case 0x13: mbc = MBC::MBC3; hasBattery = true; break;
        case 0x19: case 0x1A: case 0x1C: case 0x1D:
                                         mbc = MBC::MBC5; break;
        case 0x1B: case 0x1E:            mbc = MBC::MBC5; hasBattery = true; break;
        default:
            std::fprintf(stderr, "Warning: unsupported cartridge type 0x%02X, trying anyway\n", type);
            mbc = MBC::MBC1;
    }

    static const size_t ramSizes[] = {0, 2 * 1024, 8 * 1024, 32 * 1024, 128 * 1024, 64 * 1024};
    uint8_t ramCode = rom[0x0149];
    ram.assign(ramCode < 6 ? ramSizes[ramCode] : 0, 0);

    if (mbc == MBC::None) ramEnabled = true;  // no MBC: RAM (if any) is always on

    // Battery save lives next to the ROM: game.gb -> game.sav
    savePath = path;
    size_t dot = savePath.find_last_of('.');
    if (dot != std::string::npos) savePath.erase(dot);
    savePath += ".sav";

    if (hasBattery && !ram.empty()) {
        std::ifstream save(savePath, std::ios::binary);
        if (save) save.read(reinterpret_cast<char*>(ram.data()), ram.size());
    }

    std::printf("Loaded \"%s\" (type 0x%02X, %zu KB ROM, %zu KB RAM)\n",
                title().c_str(), type, rom.size() / 1024, ram.size() / 1024);
    return true;
}

void Cartridge::saveRam() const {
    if (!hasBattery || ram.empty()) return;
    std::ofstream save(savePath, std::ios::binary);
    save.write(reinterpret_cast<const char*>(ram.data()), ram.size());
}

std::string Cartridge::title() const {
    std::string t;
    for (int i = 0x0134; i <= 0x0143; i++) {
        char c = static_cast<char>(rom[i]);
        if (c == 0) break;
        t += c;
    }
    return t;
}

uint8_t Cartridge::read(uint16_t addr) const {
    if (addr < 0x4000) {
        // Fixed bank 0 (MBC1 "mode 1" can remap it on large ROMs)
        size_t bank = (mbc == MBC::MBC1 && mbc1Mode == 1) ? (mbc1High << 5) : 0;
        return rom[(bank * 0x4000 + addr) % rom.size()];
    }
    if (addr < 0x8000) {
        return rom[(static_cast<size_t>(romBank) * 0x4000 + (addr - 0x4000)) % rom.size()];
    }
    // 0xA000-0xBFFF: external RAM
    if (!ramEnabled || ram.empty()) return 0xFF;
    if (mbc == MBC::MBC3 && ramBank >= 0x08) return 0;  // real-time clock not emulated
    size_t bank = ramBank;
    if (mbc == MBC::MBC1 && mbc1Mode == 0) bank = 0;
    return ram[(bank * 0x2000 + (addr - 0xA000)) % ram.size()];
}

void Cartridge::write(uint16_t addr, uint8_t value) {
    // Writes to 0xA000-0xBFFF go to cartridge RAM
    if (addr >= 0xA000 && addr < 0xC000) {
        if (!ramEnabled || ram.empty()) return;
        if (mbc == MBC::MBC3 && ramBank >= 0x08) return;
        size_t bank = ramBank;
        if (mbc == MBC::MBC1 && mbc1Mode == 0) bank = 0;
        ram[(bank * 0x2000 + (addr - 0xA000)) % ram.size()] = value;
        return;
    }

    // Writes to 0x0000-0x7FFF don't change the ROM: they program the MBC
    switch (mbc) {
        case MBC::None:
            break;

        case MBC::MBC1:
            if (addr < 0x2000)      ramEnabled = (value & 0x0F) == 0x0A;
            else if (addr < 0x4000) { mbc1Low = value & 0x1F; if (mbc1Low == 0) mbc1Low = 1; }
            else if (addr < 0x6000) mbc1High = value & 0x03;
            else                    mbc1Mode = value & 0x01;
            romBank = mbc1Low | (mbc1High << 5);
            ramBank = mbc1High;
            break;

        case MBC::MBC3:
            if (addr < 0x2000)      ramEnabled = (value & 0x0F) == 0x0A;
            else if (addr < 0x4000) { romBank = value & 0x7F; if (romBank == 0) romBank = 1; }
            else if (addr < 0x6000) ramBank = value;   // 0-3 = RAM, 8-C = clock registers
            break;                                     // 0x6000+: clock latch (ignored)

        case MBC::MBC5:
            if (addr < 0x2000)      ramEnabled = (value & 0x0F) == 0x0A;
            else if (addr < 0x3000) romBank = (romBank & 0x100) | value;
            else if (addr < 0x4000) romBank = (romBank & 0xFF) | ((value & 1) << 8);
            else if (addr < 0x6000) ramBank = value & 0x0F;
            break;
    }
}
