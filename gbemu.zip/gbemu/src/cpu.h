#pragma once
#include <cstdint>

class MMU;

// The Sharp SM83 CPU (a cousin of the Z80 / 8080).
class CPU {
public:
    explicit CPU(MMU& mmu) : mmu(mmu) {}

    int step();   // runs one instruction (or interrupt), returns T-cycles used

private:
    MMU& mmu;

    // Registers, initialised to the values the boot ROM leaves behind
    uint8_t a = 0x01, f = 0xB0, b = 0x00, c = 0x13, d = 0x00, e = 0xD8, h = 0x01, l = 0x4D;
    uint16_t sp = 0xFFFE, pc = 0x0100;

    bool ime = false;            // interrupt master enable
    bool imeScheduled = false;   // EI takes effect after the next instruction
    bool halted = false;

    // Flags live in the top 4 bits of F
    enum : uint8_t { FZ = 0x80, FN = 0x40, FH = 0x20, FC = 0x10 };
    bool flag(uint8_t m) const { return f & m; }
    void setFlag(uint8_t m, bool on) { f = on ? (f | m) : (f & ~m); }

    // 16-bit register pairs
    uint16_t bc() const { return (b << 8) | c; }
    uint16_t de() const { return (d << 8) | e; }
    uint16_t hl() const { return (h << 8) | l; }
    void setBC(uint16_t v) { b = v >> 8; c = v & 0xFF; }
    void setDE(uint16_t v) { d = v >> 8; e = v & 0xFF; }
    void setHL(uint16_t v) { h = v >> 8; l = v & 0xFF; }

    uint8_t fetch8();
    uint16_t fetch16();
    void push(uint16_t v);
    uint16_t pop();

    // Opcodes encode registers as 3-bit indexes: B C D E H L (HL) A
    uint8_t getR(int i);
    void setR(int i, uint8_t v);
    // ...and register pairs as 2-bit indexes: BC DE HL SP
    uint16_t getRR(int i) const;
    void setRR(int i, uint16_t v);
    bool condition(int cc) const;   // NZ Z NC C

    void alu(int op, uint8_t v);    // ADD ADC SUB SBC AND XOR OR CP
    uint8_t inc(uint8_t v);
    uint8_t dec(uint8_t v);
    void addHL(uint16_t v);
    uint16_t addSPSigned();
    void daa();

    int execute(uint8_t op);
    int executeCB();
};
