#pragma once
#include <array>
#include <cstdint>

// The Pixel Processing Unit: draws background, window and sprites
// one scanline at a time into a 160x144 framebuffer.
class PPU {
public:
    static constexpr int WIDTH = 160;
    static constexpr int HEIGHT = 144;

    explicit PPU(uint8_t& interruptFlags) : IF(interruptFlags) {
        vram.fill(0);
        oam.fill(0);
        framebuffer.fill(palette[0]);
    }

    void tick(int cycles);

    uint8_t readVRAM(uint16_t addr) const { return vram[addr - 0x8000]; }
    void writeVRAM(uint16_t addr, uint8_t v) { vram[addr - 0x8000] = v; }
    uint8_t readOAM(uint16_t addr) const { return oam[addr - 0xFE00]; }
    void writeOAM(uint16_t addr, uint8_t v) { oam[addr - 0xFE00] = v; }

    uint8_t readReg(uint16_t addr) const;
    void writeReg(uint16_t addr, uint8_t value);

    bool lcdOn() const { return lcdc & 0x80; }

    // ARGB8888 pixels, row-major
    const uint32_t* pixels() const { return framebuffer.data(); }
    bool frameReady = false;

private:
    uint8_t& IF;
    std::array<uint8_t, 0x2000> vram;
    std::array<uint8_t, 0xA0> oam;
    std::array<uint32_t, WIDTH * HEIGHT> framebuffer;

    // LCD registers (0xFF40-0xFF4B)
    uint8_t lcdc = 0x91, stat = 0x00, scy = 0, scx = 0, ly = 0, lyc = 0;
    uint8_t bgp = 0xFC, obp0 = 0xFF, obp1 = 0xFF, wy = 0, wx = 0;

    int mode = 2;        // 0 HBlank, 1 VBlank, 2 OAM scan, 3 drawing
    int dots = 0;        // cycles spent in the current mode
    int windowLine = 0;  // the window has its own line counter

    // Classic green-tinted DMG shades, lightest to darkest
    static constexpr uint32_t palette[4] = {0xFFE0F8D0, 0xFF88C070, 0xFF346856, 0xFF081820};

    void setMode(int m);
    void compareLY();
    void renderScanline();
    uint8_t tilePixel(uint16_t tileAddr, int x, int y) const;
    uint32_t shade(uint8_t pal, uint8_t colorIndex) const { return palette[(pal >> (colorIndex * 2)) & 3]; }
};
